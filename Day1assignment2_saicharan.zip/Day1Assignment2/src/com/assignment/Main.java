package com.assignment;

public class Main {

    public static void main(String[] args) {
        Worker w = new SalariedWorker();
        w.setSalaryrate(100);
        w.setName("salaryemployee");
        int y= w.pay(100);
        System.out.println("Salary is:"+y);
        w = new DailyWorker();
        w.setSalaryrate(100);
        w.setName("dailyemployee");
        y=w.pay(100);
        System.out.println("Salary is:"+y);

	// write your code here
    }
}
