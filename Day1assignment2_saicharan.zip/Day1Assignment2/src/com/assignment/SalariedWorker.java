package com.assignment;

public class SalariedWorker extends Worker {
    int salaryrate;
    String name;

    public void setSalaryrate(int salaryrate) {
        this.salaryrate = salaryrate;
    }

    public void setName(String name) {
        this.name = name;
    }

    public  int pay(int hrs)
    {
        System.out.println(""+this.name+" gets salary for only 40hrs max");
        if(hrs<40)
        {
            return this.salaryrate*hrs;
        }
        else
        {
            return this.salaryrate*40;
        }
    }

}
