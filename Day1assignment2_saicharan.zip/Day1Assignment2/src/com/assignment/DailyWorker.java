package com.assignment;

public class DailyWorker extends Worker {
    int salaryrate;
    String name;

    public void setName(String name) {
        this.name = name;
    }

    public void setSalaryrate(int salaryrate) {
        this.salaryrate = salaryrate;
    }

    public int pay(int hrs)
    {
        System.out.println(""+this.name);
        return this.salaryrate*hrs;
    }
}
