package com.assignment;

public class Worker {
    String name;
    int salaryrate;

    public void setName(String name) {
        this.name = name;
    }

    public void setSalaryrate(int salaryrate) {
        this.salaryrate = salaryrate;
    }

    public int pay(int x)
    {

        return this.salaryrate*x;
    }
}
