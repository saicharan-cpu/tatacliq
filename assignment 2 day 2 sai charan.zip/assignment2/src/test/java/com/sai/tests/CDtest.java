package com.sai.tests;

import com.sai.util.datas.CD;
import com.sai.util.datas.imple;
import com.sai.util.datas.inter;
import com.sai.util.runs.sorter;
import org.junit.jupiter.api.AfterEach;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.DisplayName;
import org.junit.jupiter.api.Test;

import java.util.Random;

import static org.junit.jupiter.api.Assertions.assertNotEquals;
import static org.junit.jupiter.api.Assertions.assertThrows;

public class CDtest {
    private CD cd1,cd2,cd3;
    imple in;
    sorter s;

    @BeforeEach
    public void getInstance(){
        cd1=new CD();
        cd1.setSingername(""+new Random().nextInt(100));
        cd1.setTitle(""+new Random().nextInt(100));

        cd2=new CD();
        cd2.setSingername(""+new Random().nextInt(100));
        cd2.setTitle(""+new Random().nextInt(100));
        in=new imple();
        s=new sorter();
    }

    @Test
    @DisplayName("Testing  Singername to  not be null")
    public void testSingerNotNull(){
        assertNotEquals("",cd1.getSingername());
    }

    @Test
    @DisplayName("Test Title to not be null")
    public void testTitleNotNull(){

        assertNotEquals("",cd2.getTitle());
    }



    @Test
    public void negativeTestForCDInstance(){
        assertThrows(NullPointerException.class,
                ()->{
                    cd3.getSingername();
                    cd3.getTitle();
                });
    }
    @Test
    @DisplayName("Testing getrandom method doesnt return null")
    public void TestGetrandomNotNull()
    {
        assertNotEquals("",in.getrandom());
    }
    @Test
    @DisplayName("Testing getdata method doesnt return null")
    public void TestgetDataNotNull()
    {
        assertNotEquals("",in.getdata());
    }
    @Test
    @DisplayName("Testing getalldetails method doesnt return null")
    public void TestgetalldetailsNotNull()
    {
        assertNotEquals("",in.getalldetails());
    }
    @Test
    @DisplayName("Testing compare method in sorter class doesnt return null")
    public void TestcompareNotNull()
    {
        assertNotEquals("",s.compare(cd1,cd2));
    }

    @AfterEach
    public void testUnReferenceInstance(){
        cd1=null;
        cd2=null;
        cd3=null;
        in=null;
    }

}
