package com.sai.util.runs;

import com.sai.util.datas.CD;
import com.sai.util.datas.imple;

import java.util.*;

public class classmain {

    public static void main(String[] args) {
        imple x = new imple();
        System.out.println("---------Taking random input-----");
        List<CD> details = x.getdata();
        for (CD y: details) {
            System.out.println("Name of singer:"+y.getSingername()+"    title is:"+y.getTitle());

        }
        System.out.println("-----------------------------after sortinggggg------------------------------");
        Collections.sort(details,new sorter());
        for (CD y : details) {
            System.out.println("Name of singer :"+y.getSingername()+"   title is:"+y.getTitle());

        }
    }
}

