package com.sai.util.runs;

import com.sai.util.datas.CD;

import java.util.Comparator;


public class sorter implements Comparator<CD> {
        @Override
        public int  compare(CD o1, CD o2) {
            return o1.getSingername().compareTo(o2.getSingername());
        }

}
