package com.sai.util.datas;

import com.sai.util.datas.CD;

import java.util.List;

public interface inter {
    List<CD> getalldetails();
}
