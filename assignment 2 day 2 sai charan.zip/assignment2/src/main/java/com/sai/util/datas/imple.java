package com.sai.util.datas;

import java.util.ArrayList;
import java.util.List;
import java.util.Random;

public class imple implements inter {
    @Override
    public List<CD> getalldetails()

    {
        return getdata();

    }
    public String getrandom()
    {    //can add capital letters etc also
        String name="abcdefghijklmnopqrstuvxyz";

        int n=5;
         n = n+new Random().nextInt(6);
        StringBuilder sb = new StringBuilder(n);
         for (int i=0;i<n;i++) {
             int index= new Random().nextInt(25);
             sb.append(name.charAt(index));
         }
         return sb.toString();


    }
    public List<CD> getdata()
    {
        List<CD> arr=new ArrayList<CD>();
        for(int i=0;i<200;i++)
        {
            CD c = new CD();
            c.setSingername(getrandom());
            c.setTitle(getrandom());
            arr.add(c);
        }
        return arr;
    }


}
