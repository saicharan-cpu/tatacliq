package com.assignment;

import java.util.Scanner;

public class Main {

    public static void main(String[] args) {
	// write your code
        float sum=0;
        float x,y;
        Scanner s = new Scanner(System.in);
        for(int i=0;i<5;i++)
        {
            System.out.println("enter numbers(first input between 1 to 3):");
            x=s.nextInt();
            y=s.nextInt();
            switch((int) x)
            {
                case 1:
                    sum+=y*22.50;
                    break;
                case  2:
                    sum+=44.50*y;
                    break;
                case 3:
                    sum+=9.98*y;
                    break;

            }
            System.out.println("Sum is:"+sum);
        }



    }
}
