package com.shoppers.den.Dao;

import com.shoppers.den.entities.Customer;

import java.sql.SQLException;
import java.util.List;

public interface CustomerDao {
    void addCustomer(Customer customer) throws SQLException;
    List<Customer> getallcustomers() throws SQLException;
    public void addcredentials(Customer customer) throws SQLException;
}
