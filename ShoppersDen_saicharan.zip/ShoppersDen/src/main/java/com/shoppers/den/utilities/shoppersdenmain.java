package com.shoppers.den.utilities;

import com.shoppers.den.Dao.*;
import com.shoppers.den.entities.*;
import com.shoppers.den.impl.*;

import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;
import java.util.Scanner;

public class shoppersdenmain {
    public static void main(String[] args) {
        int i = 0, j = 0, k = 0, count = 0;
        long l = 0;
        int[] pids = new int[10];
        int[] qtys = new int[10];
        int[] qty = new int[10];

        //String pwd=null;
        Scanner scanner = new Scanner(System.in);
        CategoryDao categoryDao = new Categoryimpl();
        CustomerDao customerDao = new Customerimpl();
        LoginFormDao loginFormDao = new LoginFormimpl();
        AdminDao adminDao = new Adminimpl();
        ProductDao productDao = new Productimpl();
        ShoppingCartDao shoppingCartDao = new ShoppingCartDaoimpl();
        Billing billing = new Billing();
        try {
            System.out.println("1.Go to Store *************  2.Admin login (enter 1 or 2):");
            i = scanner.nextInt();
            switch (i) {
                case 1:
                    productDao.showproductsbeforelogin();
                    System.out.println("would like to add products to cart?press 'yes':");
                    String ch = scanner.nextLine();

                    System.out.println("Before adding to cart you will have to login...");
                    System.out.println("1.Login 2.New user Registration(enter 1 or 2)");
                    int loa = scanner.nextInt();
                    scanner.nextLine();
                    switch (loa) {
                        case 1:
                            System.out.println("enter userid:");
                            long u = scanner.nextLong();
                            scanner.nextLine();
                            System.out.println("enter pwd");
                            String pwd = scanner.nextLine();
                            while (true) {
                                int log = 0;

                                log = loginFormDao.validateuser(u, pwd);
                                if (log == 1) {
                                    break;
                                }
                                System.out.println("wrong credentials enter again");
                                System.out.println("enter userid:");
                                u = scanner.nextLong();
                                scanner.nextLine();
                                System.out.println("enter pwd");
                                pwd = scanner.nextLine();
                            }
                            categoryDao.getallcategories();
                            System.out.println("Which products would you like to see/buy?:");
                            productDao.showproductsafterlogin();
                            System.out.println("would like to add products to cart?press 'yes'");
                            ch = scanner.nextLine();
                            if (ch.equals("yes")) {
                                System.out.println("how many products would you like to buy from 10 available products?");
                                int no = scanner.nextInt();
                                int co=1;
                                for (int ih = 0; ih < no; ih++) {
                                    System.out.println("enter the pid of the "+co+"stproduct in order:");
                                    pids[ih] = scanner.nextInt();
                                    System.out.println("enter quantity(dont enter more than available):");
                                    qtys[ih] = scanner.nextInt();
                                    co++;
                                    shoppingCartDao.addtocart(pids[ih], qtys[ih]);
                                }
                                shoppingCartDao.viewcart();
                            }
                            billing.billingmoney();
                            shoppingCartDao.clearcart();
                            break;


                        case 2:
                            Customer c = new Customer();
                            System.out.println("Enter the unique userid you would choose and remember the id for future use:");
                            long userid = scanner.nextLong();
                            scanner.nextLine();
                            c.setUserid(userid);
                            System.out.println("enter the distinctive username:");
                            String username = scanner.nextLine();
                            c.setUsername(username);
                            System.out.println("enter the password and remember for future use:");
                            String password = scanner.nextLine();
                            c.setUpwd(password);
                            System.out.println("enter the email:");
                            String email = scanner.nextLine();
                            c.setEmail(email);
                            System.out.println("enter the phonenumber:");
                            long phonenumber = scanner.nextLong();
                            c.setPhno(phonenumber);
                            scanner.nextLine();
                            System.out.println("enter the address:");
                            String address = scanner.nextLine();
                            c.setAddress(address);
                            customerDao.addCustomer(c);
                            System.out.println("---noww login---");
                            System.out.println("enter userid:");
                            long newu = scanner.nextLong();
                            scanner.nextLine();
                            System.out.println("enter password");
                            String newpwd = scanner.nextLine();
                            while (true) {
                                int log = 0;

                                log = loginFormDao.validateuser(newu, newpwd);


                                if (log == 1) {
                                    break;
                                }
                                System.out.println("wrong credentials enter again");
                                System.out.println("enter userid:");
                                newu = scanner.nextLong();
                                scanner.nextLine();
                                System.out.println("enter pwd");
                                newpwd = scanner.nextLine();
                            }
                            categoryDao.getallcategories();
                            System.out.println("Which products would you like to see/buy?:");

                            productDao.showproductsafterlogin();

                            System.out.println("would like to add products to cart?press 'yes'");
                            ch = scanner.nextLine();
                            if (ch.equals("yes")) {
                                System.out.println("how many products would you like to buy from 10 available products?enter number form 1-no:of products available:");
                                int no = scanner.nextInt();
                                int ni=1;
                                for (int ih = 0; ih < no; ih++) {
                                    System.out.println("enter the pid of the"+ni+"st product to order:");
                                    pids[ih] = scanner.nextInt();
                                    System.out.println("enter quantity(dont enter more than available):");
                                    qtys[ih] = scanner.nextInt();
                                    ni++;
                                    shoppingCartDao.addtocart(pids[ih], qtys[ih]);
                                }
                                shoppingCartDao.viewcart();
                                billing.billingmoney();
                                shoppingCartDao.clearcart();

                            }
                            break;
                    }

                    break;


                case 2:
                    System.out.println("for admin login use aid=1 password=saireddy or view the postgres admin table for credentials");
                    System.out.println("Enter aid:");
                    j = scanner.nextInt();
                    scanner.nextLine();
                    System.out.println("Enter pwd:");
                    String adpwd = scanner.nextLine();
                    while (true) {
                        k = loginFormDao.validateadmin(j, adpwd);

                        if (k == 1) {
                            break;
                        }
                        System.out.println("wrong credentilas");
                        System.out.println("Enter aid:");
                        j = scanner.nextInt();
                        scanner.nextLine();
                        System.out.println("Enter pwd:");
                        adpwd = scanner.nextLine();
                    }
                    System.out.println("enter an option 1.view products 2.view categories 3.add product 4.add category 5.remove product 6.remove category 7.view customers( enter b/w 1-7):");
                    int choice = scanner.nextInt();
                    switch (choice) {
                        case 1:
                            productDao.showproductsafterlogin();
                            break;
                        case 2:
                            adminDao.getallcategories();
                            break;
                        case 3:
                            Product p = new Product();
                            System.out.println("enter the unique pid:");
                            int pid = scanner.nextInt();
                            p.setPid(pid);
                            scanner.nextLine();
                            System.out.println("enter distinct product name:");
                            String pname = scanner.nextLine();
                            p.setPname(pname);
                            System.out.println("enter the price of product:");
                            int price = scanner.nextInt();
                            p.setPrice(price);
                            scanner.nextLine();
                            System.out.println("enter th quantity of products available in store:");
                            int quantity = scanner.nextInt();
                            p.setQty(quantity);
                            System.out.println("enter the valid cid of the product:");
                            int cid = scanner.nextInt();
                            p.setCid(cid);
                            adminDao.addproduct(p);
                            productDao.showproductsafterlogin();
                            break;
                        case 4:
                            Category c = new Category();
                            System.out.println("enter the unique cid of category");
                            int catid = scanner.nextInt();
                            scanner.nextLine();
                            c.setCid(catid);
                            System.out.println("enter the distinct category name:");
                            String cname = scanner.nextLine();
                            c.setCname(cname);
                            adminDao.addcategory(c);
                            adminDao.getallcategories();
                            break;
                        case 5:
                            System.out.println("after executing this the output will be 'no results returned' but the row in table would be deleted");
                            System.out.println("enter the pid of the product:");
                            int pidd = scanner.nextInt();
                            scanner.nextLine();
                            adminDao.removeproduct(pidd);
                            productDao.showproductsafterlogin();
                            break;
                        case 6:
                            System.out.println("after executing this the output will be 'no results returned' but the rows in category table and products would be deleted");
                            System.out.println("enter the cid of category:");
                            int cidd = scanner.nextInt();
                            scanner.nextLine();
                            adminDao.removecategory(cidd);
                            break;
                        case 7:
                            List<Customer> customers=new ArrayList<Customer>();

                            customers=customerDao.getallcustomers();
                            for(Customer cus: customers)
                            {
                                System.out.println("uid:"+cus.getUserid()+" uname:"+cus.getUsername()+" email:"+cus.getEmail()+" phnno:"+cus.getPhno()+"address:"+cus.getAddress());
                            }

                    }



                    break;

        }
    }

            //productDao.addproduct(product);
            //loginFormDao.validate(1238,"mahesh");
        catch (SQLException exception) {
           System.out.println(exception.getMessage());
       }


    }
}
