package com.shoppers.den.impl;

import com.shoppers.den.Dao.LoginFormDao;
import com.shoppers.den.Dao.ProductDao;
import com.shoppers.den.entities.Product;
import com.shoppers.den.helpers.PostgresConnHelper;
import com.sun.media.jfxmedia.locator.ConnectionHolder;

import java.sql.*;
import java.util.ArrayList;
import java.util.List;
import java.util.ResourceBundle;
import java.util.Scanner;

public class Productimpl implements ProductDao {
    private Connection conn;
    private PreparedStatement pre;
    private Statement statement;
    private ResultSet resultSet;
    private ResourceBundle resourceBundle;
    private ProductDao newproductDao;
    private LoginFormDao loginFormDaonew;

    public Productimpl() {
        conn = PostgresConnHelper.getConnection();
        if (conn != null)
            System.out.println("Connection ready...");
        else
            System.out.println("Connection has issue...");
        resourceBundle = ResourceBundle.getBundle("db");
    }

    @Override
    public void addproduct(Product product) throws SQLException {
        String add = resourceBundle.getString("addproduct");
        try {
            pre = conn.prepareStatement(add);
            pre.setInt(1, product.getPid());
            pre.setString(2, product.getPname());
            pre.setInt(3, product.getPrice());
            pre.setInt(4, product.getQty());
            pre.setInt(5, product.getCid());
            pre.executeUpdate();
            conn.commit();
        } catch (SQLException e) {
            e.printStackTrace();
        }
    }

    @Override
    public List<Product> getproducts() throws SQLException {
        List<Product> products = null;
        String query = "select p.pid,p.pname,p.price,p.qty,p.cid from ProductsNew p order by p.pid";
        statement = conn.createStatement();
        resultSet = statement.executeQuery(query);
        products = new ArrayList<Product>();
        while (resultSet.next()) {
            Product p = new Product();
            p.setPid(resultSet.getInt(1));
            p.setPname(resultSet.getString(2));
            p.setPrice(resultSet.getInt(3));

            p.setQty(resultSet.getInt(4));
            p.setCid(resultSet.getInt(5));
            products.add(p);
        }

        return products;
    }

    @Override
    public void showproductsbeforelogin() throws SQLException {
        Scanner sc = new Scanner(System.in);
        List<Product> productList = new ArrayList<Product>();
        /*System.out.println("Which category products would you like to see/buy?(enter between 1-4):");
        int k=sc.nextInt();
        sc.nextLine();
        List<Product> productList = new ArrayList<Product>();
        productList=getproducts(k);

         */
        int count = 1;
        //while(true) {
        //System.out.println("Which category products would you like to see/buy?(enter between 1-4):");
        //int k=sc.nextInt();
        //sc.nextLine();
        productList = getproducts();
        for (Product p : productList) {
            System.out.println(count + "." +" pid:"+p.getPid()+" "+ p.getPname() + ":" + p.getPrice()+"  cid:"+p.getCid());
            System.out.println("");
            count++;
        }
        /*System.out.println("would like to add products to cart?press 'yes' for adding 'no' to view products in other Categories:");
        String ch = sc.nextLine();
        if (ch.equals("yes")) {
            break;
        }

         */

    }

    @Override
    public void showproductsafterlogin() throws SQLException {
        Scanner sc = new Scanner(System.in);
        List<Product> productList = new ArrayList<Product>();
        productList = getproducts();
        int count = 1;
        for (Product p : productList) {
            System.out.println(count + "."+" pid:"+p.getPid()+" "+ p.getPname() + " :" + p.getPrice()+"("+p.getQty()+"pieces avialable)");

            System.out.println("");
            count++;
        }

    }
}


