package com.shoppers.den.entities;

public class LoginForm {
    private String pwd;
    private long userid;
    //verifylogin function
}
