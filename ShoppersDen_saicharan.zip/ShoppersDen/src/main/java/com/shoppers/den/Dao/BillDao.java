package com.shoppers.den.Dao;

import java.sql.SQLException;

public interface BillDao {
    public void billingmoney() throws SQLException;
}
