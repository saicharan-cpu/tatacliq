package com.shoppers.den.entities;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@AllArgsConstructor
@NoArgsConstructor
public class Admin {
  private long aid;
  private String aname;
  private String apwd;
  //add prod to category
    //deleteproduct
    //deletecategory
    //update his account
    //view back
}
