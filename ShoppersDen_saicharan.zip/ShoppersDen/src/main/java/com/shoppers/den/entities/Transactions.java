package com.shoppers.den.entities;

import java.util.Date;

public class Transactions {
    private float amount;
    private int qty;
    private int  pid;
    private Date date;
    private long userid;
}
