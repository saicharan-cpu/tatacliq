package com.shoppers.den.Dao;

import com.shoppers.den.entities.Customer;

import java.sql.SQLException;

public interface LoginFormDao {
    public void addcredentials(Customer customer) throws SQLException;
    public int validateuser(long uid,String pwd) throws SQLException;
    public int  validateadmin(int aid,String pwd) throws SQLException;
}
