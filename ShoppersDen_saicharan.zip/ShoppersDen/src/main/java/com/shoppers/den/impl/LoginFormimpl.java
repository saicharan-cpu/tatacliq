package com.shoppers.den.impl;

import com.shoppers.den.Dao.LoginFormDao;
import com.shoppers.den.entities.Customer;
import com.shoppers.den.helpers.PostgresConnHelper;

import java.awt.*;
import java.sql.*;
import java.util.ResourceBundle;

public class LoginFormimpl implements LoginFormDao {
    private Connection conn;
    private PreparedStatement pre;
    private Statement statement;
    private ResultSet resultSet;
    private Customer customer;
    private ResourceBundle resourceBundle;


    @Override
    public void addcredentials(Customer customer) throws SQLException {

    }
    @Override
    public int validateuser(long uid,String pwd)  throws SQLException{
        conn= PostgresConnHelper.getConnection();
         long userid=0;
         String password=null;
        String sql = "select l.userid,l.upwd from Customers l where l.userid="+uid;
        statement= conn.createStatement();
        resultSet = statement.executeQuery(sql);
        while(resultSet.next()) {
             userid = resultSet.getLong(1);
             password = resultSet.getString(2);
        }
        System.out.println(userid);
        System.out.println(password);
        if(pwd.equals(password) && userid==uid) {
            System.out.println("Succcesful login");
            return 1;
        }


        return 0;

    }
    @Override
    public int validateadmin(int aid,String pwd) throws SQLException{
        conn=PostgresConnHelper.getConnection();
        int adminid=0;
        String password=null;

        String sql = "select a.aid,a.apwd from AdminTable a where a.aid="+aid;
        statement=conn.createStatement();
        resultSet=statement.executeQuery(sql);
        while(resultSet.next())
        {
            adminid=resultSet.getInt(1);
            password=resultSet.getString(2);


        }
        if(pwd.equals(password) && aid==adminid)
        {
            System.out.println("logggeddd in");
            return 1;
        }
        else
        {
            return 0;
        }
    }
}
