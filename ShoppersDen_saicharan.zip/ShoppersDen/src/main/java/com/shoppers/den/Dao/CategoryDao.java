package com.shoppers.den.Dao;

import com.shoppers.den.entities.Category;

import java.sql.SQLException;

public interface CategoryDao {
    public void addcategory(Category category) throws SQLException;
    public void getallcategories() throws SQLException;
}
