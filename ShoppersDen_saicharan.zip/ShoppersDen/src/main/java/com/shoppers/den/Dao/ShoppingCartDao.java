package com.shoppers.den.Dao;

import java.sql.SQLException;

public interface ShoppingCartDao {
    public void addtocart(int s,int q) throws SQLException;
    public void viewcart() throws SQLException;
    public void clearcart() throws SQLException;
}
