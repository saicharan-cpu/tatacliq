package com.shoppers.den.impl;

import com.shoppers.den.Dao.AdminDao;
import com.shoppers.den.Dao.CategoryDao;
import com.shoppers.den.Dao.ProductDao;
import com.shoppers.den.entities.Admin;
import com.shoppers.den.entities.Category;
import com.shoppers.den.entities.Product;
import com.shoppers.den.helpers.PostgresConnHelper;

import java.sql.*;
import java.util.ArrayList;
import java.util.List;
import java.util.ResourceBundle;

public class Adminimpl implements AdminDao, ProductDao, CategoryDao {
    private Connection conn;
    private PreparedStatement pre;
    private Statement statement;
    private ResultSet resultSet;
    private ResourceBundle resourceBundle;
    public Adminimpl()
    {
        conn= PostgresConnHelper.getConnection();
        if(conn!=null)
            System.out.println("Connection ready...");
        else
            System.out.println("Connection has issue...");
        resourceBundle=ResourceBundle.getBundle("db");
    }
    @Override
    public void addadmin(Admin admin) throws SQLException {
        String addadmin = resourceBundle.getString("addadmin");
        try{
            pre = conn.prepareStatement(addadmin);

            pre.setLong(1,admin.getAid());
            pre.setString(2,admin.getAname());
            pre.setString(3,admin.getApwd());
            pre.executeUpdate();
            conn.commit();
        } catch (SQLException e) {
            System.out.println(e.getMessage());

            conn.rollback();
        }
        finally
        {
            conn.close();
        }
    }

    @Override
    public void addcategory(Category category) throws SQLException {
        String addcategory = resourceBundle.getString("addcategory");
        try{
            pre = conn.prepareStatement(addcategory);

            pre.setLong(1,category.getCid());
            pre.setString(2,category.getCname());
            pre.executeUpdate();
        } catch (SQLException e) {
            System.out.println(e.getMessage());

            conn.rollback();
        }
    }

    @Override
    public void getallcategories() throws SQLException {
        String query="select c.cid,c.cname from Category c order by c.cid";
        statement=conn.createStatement();
        resultSet = statement.executeQuery(query);
        int i=1;
        while(resultSet.next())
        {
            System.out.println(i+". pid:"+resultSet.getInt(1)+" Cname:"+resultSet.getString(2));
            i++;
        }
    }


    @Override
    public void addproduct(Product product) throws SQLException {
        String add = resourceBundle.getString("addproduct");
        try {
            pre = conn.prepareStatement(add);
            pre.setInt(1, product.getPid());
            pre.setString(2, product.getPname());
            pre.setInt(3, product.getPrice());
            pre.setInt(4, product.getQty());
            pre.setInt(5, product.getCid());
            pre.executeUpdate();
        } catch (SQLException e) {
            e.printStackTrace();
        }
    }

    @Override
    public List<Product> getproducts() throws SQLException {
        List<Product> products = null;
        String query = "select p.pid,p.pname,p.price,p.qty,p.cid from ProductsNew p ";
        statement = conn.createStatement();
        resultSet = statement.executeQuery(query);
        products = new ArrayList<Product>();
        while (resultSet.next()) {
            Product p = new Product();
            p.setPid(resultSet.getInt(1));
            p.setPname(resultSet.getString(2));
            p.setPrice(resultSet.getInt(3));

            p.setQty(resultSet.getInt(4));
            p.setCid(resultSet.getInt(5));
            products.add(p);
        }

        return products;
    }
 @Override
 public void removeproduct(int x) throws SQLException
 {
     String query="delete from ProductsNew where pid="+x;
     statement=conn.createStatement();
     resultSet=statement.executeQuery(query);
 }

    @Override
    public void removecategory(int y) throws SQLException {
        String query="delete from Category where cid="+y;
        statement=conn.createStatement();
        resultSet=statement.executeQuery(query);

    }

    @Override
    public void showproductsbeforelogin() throws SQLException {

    }

    @Override
    public void showproductsafterlogin() throws SQLException {

    }
}
