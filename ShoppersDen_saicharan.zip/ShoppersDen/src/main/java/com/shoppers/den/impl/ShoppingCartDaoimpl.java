package com.shoppers.den.impl;

import com.shoppers.den.Dao.ShoppingCartDao;
import com.shoppers.den.entities.ShoppingCart;
import com.shoppers.den.helpers.PostgresConnHelper;

import java.sql.*;
import java.util.ArrayList;
import java.util.List;
import java.util.ResourceBundle;

public class ShoppingCartDaoimpl implements ShoppingCartDao {
    private Connection conn;
    private PreparedStatement pre;
    private Statement statement;
    private ResultSet resultSet;
    private ResourceBundle resourceBundle;
    @Override
    public void addtocart(int s, int q) throws SQLException {

        conn= PostgresConnHelper.getConnection();
        resourceBundle=ResourceBundle.getBundle("db");
        String query = "select p.pid,p.pname,p.price from ProductsNew p where p.pid="+s;
        statement = conn.createStatement();
        resultSet = statement.executeQuery(query);
        String addshoppingcart = resourceBundle.getString("addshoppingcart");
        try{
            pre = conn.prepareStatement(addshoppingcart);
            while(resultSet.next()) {
                pre.setInt(1,resultSet.getInt(1));
                pre.setString(2,resultSet.getString(2));
                pre.setInt(3,resultSet.getInt(3));
                pre.setInt(4, q);
                pre.executeUpdate();
            }
            System.out.println("ooooverrrrr");
        } catch (SQLException e) {
            System.out.println(e.getMessage());

            conn.rollback();
        }

    }

    @Override
    public void viewcart() throws SQLException {
        List<ShoppingCart>  shoppingCartList = new ArrayList<ShoppingCart>();
        String query="select sc.pid,sc.pname,sc.price,sc.qty from ShoppingCart as sc";
        statement=conn.createStatement();
        resultSet=statement.executeQuery(query);
        while(resultSet.next())
        {
            ShoppingCart sc=new ShoppingCart();
            sc.setPid(resultSet.getInt(1));
            sc.setPname(resultSet.getString(2));
            sc.setPrice(resultSet.getInt(3));
            sc.setQty(resultSet.getInt(4));
           shoppingCartList.add(sc);
        }
        int c=1;
        for(ShoppingCart sc:shoppingCartList)
        {

            System.out.println(c+". "+"pid:"+sc.getPid()+" "+sc.getPname()+" "+sc.getPrice()+" --"+sc.getQty());
            c++;
        }
    }

    @Override
    public void clearcart() throws SQLException {
        String query="delete from ShoppingCart";
        statement=conn.createStatement();
        resultSet=statement.executeQuery(query);
        System.out.println("overrrrrr shopping");
    }





}
