package com.shoppers.den.Dao;

import com.shoppers.den.entities.Product;

import java.sql.SQLException;
import java.util.List;

public interface ProductDao {
    public void addproduct(Product product) throws SQLException;
    public List<Product> getproducts() throws SQLException;
    public void showproductsbeforelogin() throws SQLException;
    public void showproductsafterlogin() throws SQLException;
}
