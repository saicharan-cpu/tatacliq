package com.shoppers.den.entities;

import com.shoppers.den.Dao.BillDao;
import com.shoppers.den.helpers.PostgresConnHelper;

import java.sql.Connection;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;

public class Billing  implements BillDao {
    private float bill;
    private int qty;
        private Statement statement;
        private Connection conn;
        private ResultSet resultSet;
    public Billing()
        {
            conn= PostgresConnHelper.getConnection();
        }

    @Override
    public void billingmoney() throws SQLException {
        String query="select sc.price,sc.qty from ShoppingCart as sc";
        statement=conn.createStatement();
        resultSet=statement.executeQuery(query);
        while(resultSet.next())
        {
            this.bill+=resultSet.getInt(1)*resultSet.getInt(2);

        }
        System.out.println("finallllll amount is: "+this.bill);
    }
}



    //buy fucntion

