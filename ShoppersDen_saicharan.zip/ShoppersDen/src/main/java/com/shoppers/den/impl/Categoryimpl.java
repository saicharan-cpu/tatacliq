package com.shoppers.den.impl;

import com.shoppers.den.Dao.CategoryDao;
import com.shoppers.den.entities.Category;
import com.shoppers.den.helpers.PostgresConnHelper;

import java.sql.*;
import java.util.ResourceBundle;

public class Categoryimpl implements CategoryDao {
    private Connection conn;
    private PreparedStatement pre;
    private Statement statement;
    private ResultSet resultSet;
    private ResourceBundle resourceBundle;
    public Categoryimpl()
    {
        conn= PostgresConnHelper.getConnection();
        if(conn!=null)
            System.out.println("Connection ready...");
        else
            System.out.println("Connection has issue...");
        resourceBundle=ResourceBundle.getBundle("db");
    }
    @Override
    public void addcategory(Category category) throws SQLException {
        String addcategory = resourceBundle.getString("addcategory");
        try{
            pre = conn.prepareStatement(addcategory);

            pre.setLong(1,category.getCid());
            pre.setString(2,category.getCname());
            pre.executeUpdate();
            conn.commit();
        } catch (SQLException e) {
            System.out.println(e.getMessage());

            conn.rollback();
        }

    }

    @Override
    public void getallcategories() throws SQLException {
        String query=resourceBundle.getString("selectcategory");
        statement=conn.createStatement();
        resultSet = statement.executeQuery(query);
        int i=1;
        while(resultSet.next())
        {
            System.out.println(i+"."+resultSet.getString(1));
            i++;
        }
    }

}
