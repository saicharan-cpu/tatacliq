package com.shoppers.den.helpers;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.SQLException;
import java.util.ResourceBundle;

public class PostgresConnHelper {
    private static ResourceBundle resourceBundle;
    private static Connection conn;
    public static Connection getConnection()
    {
        //resource bundle reads property file.name of the file is db.propertirs hence we put
        resourceBundle= ResourceBundle.getBundle("db");
        String username=resourceBundle.getString("username");
        String password= resourceBundle.getString("password");
        String url = resourceBundle.getString("url");
        try {
            conn = DriverManager.getConnection(url,username,password);
        } catch (SQLException e) {
            System.out.println(e.getMessage());

        }
        return  conn;
    }
}
