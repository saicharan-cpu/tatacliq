package com.shoppers.den.impl;

import com.shoppers.den.Dao.CustomerDao;
import com.shoppers.den.Dao.LoginFormDao;
import com.shoppers.den.entities.Customer;
import java.sql.*;
import java.util.ArrayList;
import java.util.List;
import java.util.ResourceBundle;
import com.shoppers.den.helpers.PostgresConnHelper;

public class Customerimpl implements CustomerDao,LoginFormDao {
   private Connection conn;
   private PreparedStatement pre;
   private Statement statement;
   private ResultSet resultSet;
   private Customer customer;
   private ResourceBundle resourceBundle;
   public Customerimpl()
   {
       conn= PostgresConnHelper.getConnection();
       if(conn!=null)
           System.out.println("Connection ready...");
       else
           System.out.println("Connection has issue...");


       resourceBundle=ResourceBundle.getBundle("db");
   }
    @Override
    public void addCustomer(Customer customer) throws SQLException {
       String addcustomer = resourceBundle.getString("addcustomer");
       try{
           pre = conn.prepareStatement(addcustomer);

               pre.setLong(1,customer.getUserid());
               pre.setString(2,customer.getUsername());
               pre.setString(3,customer.getUpwd());

               pre.setString(4,customer.getEmail());
               pre.setLong(5,customer.getPhno());
               pre.setString(6,customer.getAddress());
                pre.executeUpdate();
           } catch (SQLException e) {
           System.out.println(e.getMessage());


           }

       }
       @Override
      public List<Customer> getallcustomers() throws SQLException {
          conn=PostgresConnHelper.getConnection();
          List<Customer> customerList;
          String query = null;
          query="select c.userid,c.username,c.upwd,c.email,c.phno,c.address from Customers c";

              statement=conn.createStatement();
              resultSet = statement.executeQuery(query);
              customerList = new ArrayList<Customer>();
              while(resultSet.next())
              {
                  Customer cus=new Customer();
                  cus.setUserid(resultSet.getLong(1));
                  cus.setUsername(resultSet.getString(2));
                  cus.setUpwd(resultSet.getString(3));
                  cus.setEmail(resultSet.getString(4));
                  cus.setPhno(resultSet.getLong(5));
                  cus.setAddress(resultSet.getString(6));
                  customerList.add(cus);
              }


            return customerList;
      }

    @Override
    public void addcredentials(Customer customer) throws SQLException {
            conn=PostgresConnHelper.getConnection();
            String addloginform = resourceBundle.getString("addloginform");
            try{
                pre = conn.prepareStatement(addloginform);

                pre.setLong(1,customer.getUserid());
                pre.setString(2,customer.getUpwd());
                pre.executeUpdate();
                conn.commit();
            } catch (SQLException e) {
                System.out.println(e.getMessage());

                try {
                    conn.rollback();
                } catch (SQLException ex) {
                    ex.printStackTrace();
                }
            }
        }

    @Override
    public int validateuser(long uid, String pwd) throws SQLException {
        return 0;
    }


    @Override
    public int validateadmin(int aid, String pwd) throws SQLException {
        return 0;
    }
}




