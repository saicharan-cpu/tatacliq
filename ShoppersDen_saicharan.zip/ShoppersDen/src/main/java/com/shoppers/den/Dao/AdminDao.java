package com.shoppers.den.Dao;

import com.shoppers.den.entities.Admin;
import com.shoppers.den.entities.Category;
import com.shoppers.den.entities.Product;

import java.sql.SQLException;

public interface AdminDao {
    public void addadmin(Admin a) throws SQLException;
    public void addcategory(Category category) throws SQLException;
    public void getallcategories() throws SQLException;
    public void addproduct(Product product) throws SQLException;
    public void removeproduct(int x) throws SQLException;
    public void removecategory(int y)throws SQLException;

}
