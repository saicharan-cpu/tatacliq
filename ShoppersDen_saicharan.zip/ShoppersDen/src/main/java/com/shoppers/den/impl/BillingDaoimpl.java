package com.shoppers.den.impl;

import com.shoppers.den.Dao.BillDao;
import com.shoppers.den.helpers.PostgresConnHelper;

import java.sql.Connection;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;

public class BillingDaoimpl implements BillDao {
    private Statement statement;
    private Connection conn;
    private ResultSet resultSet;
    public BillingDaoimpl()
    {
        conn= PostgresConnHelper.getConnection();
    }
    @Override
    public void billingmoney() throws SQLException {
        String query="select sc.price,sc.qty from ShoppingCart as sc";
        statement=conn.createStatement();
        resultSet=statement.executeQuery(query);
        while(resultSet.next())
        {

        }
    }
}
