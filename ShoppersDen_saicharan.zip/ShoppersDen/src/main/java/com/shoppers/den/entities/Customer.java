package com.shoppers.den.entities;


import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

import java.util.Set;
@Data
@NoArgsConstructor
@AllArgsConstructor

public class Customer {
    private long  userid;
    private String upwd;
    private String username;
    private String email;
    private long phno;
    private String address;
}
